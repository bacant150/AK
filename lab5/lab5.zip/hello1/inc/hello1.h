/* SPDX-License-Identifier: Dual BSD/GPL */

#ifndef HELLO1_H
#define HELLO1_H

#include <linux/types.h>

extern int print_hello(uint param);

#endif /* HELLO1_H */
